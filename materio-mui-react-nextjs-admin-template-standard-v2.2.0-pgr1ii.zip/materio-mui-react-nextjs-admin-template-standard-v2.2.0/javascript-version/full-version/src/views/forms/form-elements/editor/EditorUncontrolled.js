// ** Component Import
import ReactDraftWysiwyg from 'src/@core/components/react-draft-wysiwyg'

const EditorUncontrolled = () => <ReactDraftWysiwyg />

export default EditorUncontrolled
